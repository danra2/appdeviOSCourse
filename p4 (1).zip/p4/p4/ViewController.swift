//
//  ViewController.swift
//  p4
//
//  Created by Kevin Chan on 2/28/18.
//  Copyright © 2018 Kevin Chan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, SongDelegate {

    var playlistTableView: UITableView!
    var songs: [Song] = [Song]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Songs"
        
        view.backgroundColor = .white
        
        createSongs()
        
        // Setup views
        playlistTableView = UITableView()
        playlistTableView.translatesAutoresizingMaskIntoConstraints = false
        playlistTableView.register(PlaylistCell.self, forCellReuseIdentifier: "playlistCellID")
        playlistTableView.backgroundColor = .black
        playlistTableView.separatorStyle = .none
        playlistTableView.delegate = self
        playlistTableView.dataSource = self
        view.addSubview(playlistTableView)
        
        setConstraints()
    }
    
    // MARK: - CONSTRAINTS
    func setConstraints() {
        playlistTableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        playlistTableView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        playlistTableView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        playlistTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
    }
    
    // MARK: - Setup models
    func createSongs() {
        let song1 = Song(name: "Gang Related", artist: "Logic", album: "Under Pressure", image: #imageLiteral(resourceName: "underpressure"))
        let song2 = Song(name: "Walk On Water (ft. Beyonce)",artist: "Eminem", album: "Revival", image: #imageLiteral(resourceName: "revival"))
        let song3 = Song(name: "Camila", artist: "Camila Cabello", album: "Havana", image: #imageLiteral(resourceName: "havana"))
        let song4 = Song(name: "First Day Out", artist: "Tee Grizzley", album: "My Moment", image: #imageLiteral(resourceName: "mymoment"))
        let song5 = Song(name: "Liability", artist: "Lorde", album: "Melodrama", image: #imageLiteral(resourceName: "melodrama"))
        let song6 = Song(name: "Honeymoon Avenue", artist: "Ariana Grande", album: "Yours Truly", image: #imageLiteral(resourceName: "yourstruly"))
        let song7 = Song(name: "Mercy", artist: "Shawn Mendes", album: "Illuminate", image: #imageLiteral(resourceName: "illuminate"))
        let song8 = Song(name: "One Call Away", artist: "Charlie Puth", album: "Nine Track Mind", image: #imageLiteral(resourceName: "ninetrackmind"))
        let song9 = Song(name: "Midnight Train", artist: "Sam Smith", album: "The Thrill Of It All", image: #imageLiteral(resourceName: "thrillofitall"))
        let song10 = Song(name: "Finesse", artist: "Bruno Mars", album: "24k Magic", image: #imageLiteral(resourceName: "24kmagic"))
        songs = [song1, song2, song3, song4, song5, song6, song7, song8, song9, song10]
    }
    
    // MARK: - TABLEVIEW METHODS
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "playlistCellID", for: indexPath) as! PlaylistCell
        let song = songs[indexPath.row]
        cell.songImageView.image = song.image
        cell.songNameLabel.text = song.name
        cell.infoLabel.text = "\(song.artist) • \(song.album)"
        cell.backgroundColor = .black
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return songs.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    // Show DetailViewController
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let song = songs[indexPath.row]
        let detailVC = DetailViewController()
        detailVC.row = indexPath.row
        detailVC.song = song
        detailVC.songDelegate = self
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    // MARK: - Delegate method used to tell when DetailVC is popped
    func changedSong(row: Int, song: Song) {
        songs[row] = song
        playlistTableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

