//
//  Song.swift
//  p4
//
//  Created by Kevin Chan on 2/28/18.
//  Copyright © 2018 Kevin Chan. All rights reserved.
//

import UIKit

class Song {
    
    var name: String
    var artist: String
    var album: String
    var image: UIImage
    
    init(name: String, artist: String, album: String, image: UIImage) {
        self.name = name
        self.artist = artist
        self.album = album
        self.image = image
        
    }
    
}
