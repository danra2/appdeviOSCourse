//
//  DetailViewController.swift
//  p4
//
//  Created by Kevin Chan on 3/1/18.
//  Copyright © 2018 Kevin Chan. All rights reserved.
//

import UIKit

// MARK: - Delegate to let ViewController know when DetailVC is done editing
protocol SongDelegate {
    func changedSong(row: Int, song: Song)
}

class DetailViewController: UIViewController {
    
    var row: Int!
    var song: Song!
    var songDelegate: SongDelegate!
    
    var songLabel: UILabel!
    var artistLabel: UILabel!
    var albumLabel: UILabel!
    var songTextField: UITextField!
    var artistTextField: UITextField!
    var albumTextField: UITextField!
    var songImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = song.name
        view.backgroundColor = .black
        
        songLabel = UILabel()
        songLabel.translatesAutoresizingMaskIntoConstraints = false
        songLabel.textAlignment = .center
        songLabel.text = "Song:"
        songLabel.textColor = .silver
        songLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        view.addSubview(songLabel)
        
        artistLabel = UILabel()
        artistLabel.translatesAutoresizingMaskIntoConstraints = false
        artistLabel.textAlignment = .center
        artistLabel.text = "Artist:"
        artistLabel.textColor = .silver
        artistLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        view.addSubview(artistLabel)
        
        albumLabel = UILabel()
        albumLabel.translatesAutoresizingMaskIntoConstraints = false
        albumLabel.textAlignment = .center
        albumLabel.text = "Album:"
        albumLabel.textColor = .silver
        albumLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        view.addSubview(albumLabel)
        
        songTextField = UITextField()
        songTextField.translatesAutoresizingMaskIntoConstraints = false
        songTextField.backgroundColor = .white
        songTextField.text = song.name
        songTextField.font = UIFont.systemFont(ofSize: 16)
        songTextField.layer.cornerRadius = 6
        songTextField.layer.borderColor = UIColor.silver.cgColor
        songTextField.layer.borderWidth = 1
        view.addSubview(songTextField)
        
        artistTextField = UITextField()
        artistTextField.translatesAutoresizingMaskIntoConstraints = false
        artistTextField.text = song.artist
        artistTextField.font = UIFont.systemFont(ofSize: 16)
        artistTextField.backgroundColor = .white
        artistTextField.layer.cornerRadius = 6
        artistTextField.layer.borderColor = UIColor.silver.cgColor
        artistTextField.layer.borderWidth = 1
        view.addSubview(artistTextField)
        
        albumTextField = UITextField()
        albumTextField.translatesAutoresizingMaskIntoConstraints = false
        albumTextField.text = song.album
        albumTextField.backgroundColor = .white
        albumTextField.font = UIFont.systemFont(ofSize: 16)
        albumTextField.layer.cornerRadius = 6
        albumTextField.layer.borderColor = UIColor.silver.cgColor
        albumTextField.layer.borderWidth = 1
        view.addSubview(albumTextField)
        
        songImageView = UIImageView()
        songImageView.translatesAutoresizingMaskIntoConstraints = false
        songImageView.contentMode = .scaleAspectFill
        songImageView.image = song.image
        view.addSubview(songImageView)
        
        setConstraints()
    }
    
    // MARK: - CONSTRAINTS
    func setConstraints() {
        songLabel.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 18).isActive = true
        songLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 18).isActive = true
        songLabel.widthAnchor.constraint(equalToConstant: 60).isActive = true
        songLabel.heightAnchor.constraint(equalToConstant: 20).isActive = true
        
        artistLabel.leftAnchor.constraint(equalTo: songLabel.leftAnchor).isActive = true
        artistLabel.topAnchor.constraint(equalTo: songLabel.bottomAnchor, constant: 24).isActive = true
        artistLabel.widthAnchor.constraint(equalTo: songLabel.widthAnchor).isActive = true
        artistLabel.heightAnchor.constraint(equalTo: songLabel.heightAnchor).isActive = true
        
        albumLabel.leftAnchor.constraint(equalTo: songLabel.leftAnchor).isActive = true
        albumLabel.topAnchor.constraint(equalTo: artistLabel.bottomAnchor, constant: 24).isActive = true
        albumLabel.widthAnchor.constraint(equalTo: songLabel.widthAnchor).isActive = true
        albumLabel.heightAnchor.constraint(equalTo: songLabel.heightAnchor).isActive = true
        
        songTextField.leftAnchor.constraint(equalTo: songLabel.rightAnchor, constant: 10).isActive = true
        songTextField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -18).isActive = true
        songTextField.heightAnchor.constraint(equalToConstant: 30).isActive = true
        songTextField.centerYAnchor.constraint(equalTo: songLabel.centerYAnchor).isActive = true
        
        artistTextField.leftAnchor.constraint(equalTo: songTextField.leftAnchor).isActive = true
        artistTextField.centerYAnchor.constraint(equalTo: artistLabel.centerYAnchor).isActive = true
        artistTextField.rightAnchor.constraint(equalTo: songTextField.rightAnchor).isActive = true
        artistTextField.heightAnchor.constraint(equalTo: songTextField.heightAnchor).isActive = true
        
        albumTextField.leftAnchor.constraint(equalTo: songTextField.leftAnchor).isActive = true
        albumTextField.centerYAnchor.constraint(equalTo: albumLabel.centerYAnchor).isActive = true
        albumTextField.rightAnchor.constraint(equalTo: songTextField.rightAnchor).isActive = true
        albumTextField.heightAnchor.constraint(equalTo: songTextField.heightAnchor).isActive = true
        
        songImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        songImageView.widthAnchor.constraint(equalToConstant: 300).isActive = true
        songImageView.heightAnchor.constraint(equalToConstant: 300).isActive = true
        songImageView.topAnchor.constraint(equalTo: albumTextField.bottomAnchor, constant: 100).isActive = true
    }
    
    // MARK: - let SongDelegate know that DetailVC is disappearing
    override func viewWillDisappear(_ animated: Bool) {
        if let name = songTextField.text {
            song.name = name
        }
        if let artist = artistTextField.text {
            song.artist = artist
        }
        if let album = albumTextField.text {
            song.album = album
        }
        songDelegate.changedSong(row: row, song: song)
    }
    
}
