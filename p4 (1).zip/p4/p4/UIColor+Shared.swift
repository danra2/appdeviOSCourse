//
//  UIColor+Shared.swift
//  p4
//
//  Created by Kevin Chan on 3/1/18.
//  Copyright © 2018 Kevin Chan. All rights reserved.
//

import UIKit

extension UIColor {
    @nonobjc static let silver = UIColor(red: 189/255, green: 195/255, blue: 199/255, alpha: 1.0)
}
