//
//  ViewController.swift
//  p3
//
//  Created by Matthew Barker on 3/3/18.
//  Copyright © 2018 Walker White. All rights reserved.
//

import UIKit

enum ShapeType: String {
    case square, circle
}

class ArenaViewController: UIViewController {
    
    /// The diameter with which to draw the shape
    let shapeSize: CGFloat = 40
    
    var name: String? = "Arena"
    var color: UIColor = .black
    var shapeType: ShapeType? = .square
    
    var sender: UIButton? = nil
    
    var textField: UITextField = UITextField()

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        navigationItem.title = name
        view.backgroundColor = .white
        
        // Save Button
        
        let saveButton = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(savePressed))
        navigationItem.rightBarButtonItem = saveButton
        
        // Create Elements
        
        let inset: CGFloat = 20
        
        let textFieldLabel = UILabel()
        textFieldLabel.text = "Arena Name:"
        textFieldLabel.textAlignment = .right
        textFieldLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textFieldLabel)
        
        textField.text = name
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textField)
        
        // Constraints
        
        textFieldLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: inset).isActive = true
        textFieldLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: inset).isActive = true
        textFieldLabel.widthAnchor.constraint(equalToConstant: textFieldLabel.intrinsicContentSize.width).isActive = true
        
        textField.leadingAnchor.constraint(equalTo: textFieldLabel.trailingAnchor, constant: inset).isActive = true
        textField.centerYAnchor.constraint(equalTo: textFieldLabel.centerYAnchor).isActive = true
        textField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -inset).isActive = true
        textField.heightAnchor.constraint(equalToConstant: 44).isActive = true
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: view) {
           drawShape(at: point)
        }
    }
    
    /// Draws the arena's shape centered at the user's touch
    func drawShape(at point: CGPoint) {
        
        let shape = UIView(frame: CGRect(x: 0, y: 0, width: shapeSize, height: shapeSize))
        shape.backgroundColor = color
        shape.center = point
        
        if shapeType == .circle {
            shape.layer.cornerRadius = shape.frame.width / 2
        }
        
        view.addSubview(shape)
        
    }
    
    /// If new arena title valid, save name and dismiss view controller
    @objc func savePressed() {
        
        // Data Validation
        if let newName = textField.text, newName != "" {
            name = newName
            sender?.setTitle(newName, for: .normal)
        }
        
        // Present Error
        else {
            let title = "Invalid Arena Name!"
            let message = "Do you think they named colosseums nothing!? Well, it is just The Colosseum. Bad example. Give your arena a name!"
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Sheesh...", style: .cancel, handler: { (_) in
                self.textField.text = self.name
                self.textField.becomeFirstResponder()
            }))
            present(alertController, animated: true)
        }
        
        // Dismiss based on context.
        if self != navigationController?.viewControllers.first {
            // Can pop to previous view controller
            navigationController?.popViewController(animated: true)
        } else {
            // Must be in modal with one root view controller, so dismiss
            dismiss(animated: true)
        }
        
    }
    
}

