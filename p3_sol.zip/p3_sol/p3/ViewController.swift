//
//  ViewController.swift
//  p3
//
//  Created by Matthew Barker on 3/3/18.
//  Copyright © 2018 Walker White. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var redSquareArena: UIButton = UIButton()
    var blueCircleArena: UIButton = UIButton()

    override func viewDidLoad() {
        
        super.viewDidLoad()

        navigationItem.title = "Drawing Arenas"
        view.backgroundColor = .white
        
        // Create Elements
        
        redSquareArena.setTitle("Red Square Arena", for: .normal)
        redSquareArena.setTitleColor(.red, for: .normal)
        redSquareArena.translatesAutoresizingMaskIntoConstraints = false
        redSquareArena.addTarget(self, action: #selector(pushRedArenaViewController), for: .touchUpInside)
        view.addSubview(redSquareArena)
        
        blueCircleArena.setTitle("Blue Circle Arena", for: .normal)
        blueCircleArena.setTitleColor(.blue, for: .normal)
        blueCircleArena.translatesAutoresizingMaskIntoConstraints = false
        blueCircleArena.addTarget(self, action: #selector(pushBlueArenaViewController), for: .touchUpInside)
        view.addSubview(blueCircleArena)
        
        // Constaints
        
        let spacing: CGFloat = 40
        
        redSquareArena.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        redSquareArena.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -spacing).isActive = true
        
        blueCircleArena.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        blueCircleArena.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: spacing).isActive = true
        
    }

    /// Pushes a new "Red Square Arena" view controller to draw red squares
    @objc func pushRedArenaViewController(_ target: UIButton) {
        
        let arenaViewController = ArenaViewController()
        arenaViewController.sender = target
        arenaViewController.name = target.currentTitle
        arenaViewController.color = .red
        arenaViewController.shapeType = .square
        navigationController?.pushViewController(arenaViewController, animated: true)
        
        // Change title from being default back button text
        let backButton = UIBarButtonItem()
        backButton.title = "Back"
        navigationItem.backBarButtonItem = backButton
        
    }
    
    /// Pushes a new "Blue Circle Arena" view controller modally to draw blue circles
    @objc func pushBlueArenaViewController(_ target: UIButton) {
        
        let arenaViewController = ArenaViewController()
        arenaViewController.sender = target
        arenaViewController.name = target.currentTitle
        arenaViewController.color = .blue
        arenaViewController.shapeType = .circle
        
        let modalNavigationController = UINavigationController(rootViewController: arenaViewController)
        let dismissButton = UIBarButtonItem(title: "Dismiss", style: .plain,
                                            target: self, action: #selector(dismissViewController))
        arenaViewController.navigationItem.leftBarButtonItem = dismissButton
        navigationController?.present(modalNavigationController, animated: true)
        
    }
    
    /// Dismiss current view controller (wrapper for button action)
    @objc func dismissViewController() {
        dismiss(animated: true)
    }

}

