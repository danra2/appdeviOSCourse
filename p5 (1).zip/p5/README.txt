Challenge #1: Clicking on one of the restaurant cells will be pushed to a detail page of the restaurant.

Challenge #4: AND filtering on different categories 