//
//  Restaurant.swift
//  lc934_p5
//
//  Created by OSX virtual machine on 10/31/18.
//  Copyright © 2018 OSX virtual machine. All rights reserved.
//

import Foundation

enum FoodType {
    case American
    case Chinese
    case Japanese
    case Korean
    case Thai
}

enum Rating {
    case terrible
    case bad
    case moderate
    case good
    case great
}

enum CostLevel {
    case one
    case two
    case three
    case four
}

class Restaurant {
    var name: String
    var typeOfFood: FoodType
    var rating: Rating
    var costLevel: CostLevel
    var imgName: String
    
    init(name: String, typeOfFood: FoodType, rating: Rating, costLevel: CostLevel, imgName: String) {
        self.name = name
        self.typeOfFood = typeOfFood
        self.rating = rating
        self.costLevel = costLevel
        self.imgName = imgName
    }
}
