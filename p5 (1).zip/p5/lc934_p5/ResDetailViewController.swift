//
//  ResDetailViewController.swift
//  lc934_p5
//
//  Created by OSX virtual machine on 11/3/18.
//  Copyright © 2018 OSX virtual machine. All rights reserved.
//

import UIKit

class ResDetailViewController: UIViewController {
    var restaurant = Restaurant(name: "Northstar House", typeOfFood: .American, rating: .moderate, costLevel: .two, imgName: "r1")
    
    var nameLabel: UILabel!
    var typeLabel: UILabel!
    var ratingLabel: UILabel!
    var costLabel: UILabel!
    var imageView: UIImageView!
    
    var padding: Int = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        title = restaurant.name
                
        imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.image = UIImage(named: restaurant.imgName)
        view.addSubview(imageView)
        
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        nameLabel.text = restaurant.name
        view.addSubview(nameLabel)
        
        typeLabel = UILabel()
        typeLabel.translatesAutoresizingMaskIntoConstraints = false
        typeLabel.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        typeLabel.text = "Type Of food: \(restaurant.typeOfFood)"
        view.addSubview(typeLabel)
        
        costLabel = UILabel()
        costLabel.translatesAutoresizingMaskIntoConstraints = false
        costLabel.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        costLabel.text = "Cost: \(getCostLevel(costLevel: restaurant.costLevel))"
        view.addSubview(costLabel)
        
        ratingLabel = UILabel()
        ratingLabel.translatesAutoresizingMaskIntoConstraints = false
        ratingLabel.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        ratingLabel.textAlignment = .right
        ratingLabel.text = "Rating: \(getRating(rating: restaurant.rating))"
        view.addSubview(ratingLabel)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            imageView.widthAnchor.constraint(equalTo: view.widthAnchor)
            ])
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 100),
            nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            nameLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant:100)
            ])
        NSLayoutConstraint.activate([
            typeLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 20),
            typeLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor)
            ])
        NSLayoutConstraint.activate([
            costLabel.topAnchor.constraint(equalTo: typeLabel.bottomAnchor, constant: 20),
            costLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor)
            ])
        NSLayoutConstraint.activate([
            ratingLabel.topAnchor.constraint(equalTo: costLabel.bottomAnchor, constant: 20),
            ratingLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor)
            ])
    }
    private func getRating(rating: Rating) -> String {
        switch rating {
        case .terrible:
            return "Terrible"
        case .bad:
            return "Bad"
        case .moderate:
            return "Moderate"
        case .good:
            return "Good"
        default:
            return "Great"
        }
    }
    private func getCostLevel(costLevel: CostLevel) -> String {
        switch costLevel {
        case .one:
            return "$"
        case .two:
            return "$$"
        case .three:
            return "$$$"
        default:
            return "$$$$"
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
