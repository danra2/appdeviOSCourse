//
//  RestaurantCollectionViewCell.swift
//  lc934_p5
//
//  Created by OSX virtual machine on 10/31/18.
//  Copyright © 2018 OSX virtual machine. All rights reserved.
//

import UIKit

class RestaurantCollectionViewCell: UICollectionViewCell {
    
    var nameLabel: UILabel!
    var subLabel: UILabel!
    var ratingLabel: UILabel!
    var imageView: UIImageView!
    
    let padding: CGFloat = 8
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        contentView.backgroundColor = .white
        
        imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleToFill
        contentView.addSubview(imageView)
        
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        contentView.addSubview(nameLabel)
        
        subLabel = UILabel()
        subLabel.translatesAutoresizingMaskIntoConstraints = false
        subLabel.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        contentView.addSubview(subLabel)
        
        ratingLabel = UILabel()
        ratingLabel.translatesAutoresizingMaskIntoConstraints = false
        ratingLabel.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        ratingLabel.textAlignment = .right
        contentView.addSubview(ratingLabel)
        
        
    }
    override func updateConstraints() {
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.heightAnchor.constraint(equalTo: contentView.heightAnchor, multiplier: 2/3)
//            imageView.heightAnchor.constraint(equalToConstant: 200)
            ])
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: padding),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            nameLabel.widthAnchor.constraint(equalTo: contentView.widthAnchor, multiplier: 2/3)
            ])
        NSLayoutConstraint.activate([
            ratingLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: padding),
            ratingLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: padding*(-1) ),
            ratingLabel.heightAnchor.constraint(equalTo: nameLabel.heightAnchor)
            ])
        NSLayoutConstraint.activate([
            subLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: padding),
            subLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding)
            ])
        super.updateConstraints()
    }
    func configure(for restaurant: Restaurant) {
        nameLabel.text = restaurant.name
        subLabel.text = "\(getCostLevel(costLevel: restaurant.costLevel)) · \(restaurant.typeOfFood)"
        ratingLabel.text = getRating(rating: restaurant.rating)
        imageView.image = UIImage(named: restaurant.imgName)
        
    }
    private func getRating(rating: Rating) -> String {
        switch rating {
        case .terrible:
            return "Terrible"
        case .bad:
            return "Bad"
        case .moderate:
            return "Moderate"
        case .good:
            return "Good"
        default:
            return "Great"
        }
    }
    private func getCostLevel(costLevel: CostLevel) -> String {
        switch costLevel {
        case .one:
            return "$"
        case .two:
            return "$$"
        case .three:
            return "$$$"
        default:
            return "$$$$"
        }
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
