//
//  FilterCollectionViewCell.swift
//  lc934_p5
//
//  Created by OSX virtual machine on 11/2/18.
//  Copyright © 2018 OSX virtual machine. All rights reserved.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    
    var attrText: UILabel!
    
    override var isSelected: Bool {
        didSet{
            if self.isSelected == true {
                self.attrText.backgroundColor = UIColor(red:0.14, green:0.68, blue:1.00, alpha:1.0)
                self.attrText.textColor = .white
            } else {
                self.attrText.backgroundColor = .white
                self.attrText.textColor = UIColor(red:0.14, green:0.68, blue:1.00, alpha:1.0)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        attrText = UILabel()
        attrText.translatesAutoresizingMaskIntoConstraints = false
        attrText.font = UIFont.systemFont(ofSize: 12)
        attrText.backgroundColor = .white
        attrText.textColor = UIColor(red:0.14, green:0.68, blue:1.00, alpha:1.0)
        attrText.textAlignment = .center
        attrText.layer.masksToBounds = true
        attrText.layer.cornerRadius = 5
        contentView.addSubview(attrText)
        
    }
    override func updateConstraints() {
        NSLayoutConstraint.activate([
            attrText.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            attrText.widthAnchor.constraint(equalToConstant: 80),
            attrText.heightAnchor.constraint(equalToConstant: 24)
            ])
        super.updateConstraints()
    }

    func configure(for attr: String) {
        attrText.text = attr
        
    }


    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
