//
//  ViewController.swift
//  lc934_p5
//
//  Created by OSX virtual machine on 10/31/18.
//  Copyright © 2018 OSX virtual machine. All rights reserved.
//
// no filter option auto display all restaurants
// challenges
// 2. button to switch between 2 restaurants and 1 restaurant in a row
// 3. add search bar search attributes
// 4. AND filter if attributes in different categories

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
//    var headerView: UICollectionReusableView!
    var filterCollectionView: UICollectionView!
    var twoPerRowCollectionView: UICollectionView!
    var refreshControl: UIRefreshControl!
    
    var restaurantArray: [Restaurant]!
    var filteredRestaurantArray: [Restaurant]!
    
    var attributesDict: [String: [String]]!
    var attributesArray: [String]!
    
    let filterReuseIdentifier = "filterReuseIdentifier"
    let restaurantCellReuseIdentifier = "restaurantCellReuseIdentifier"
    let padding: CGFloat = 8
    let filterHeight: CGFloat = 40
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "My Restaurants"
        view.backgroundColor = UIColor(red:0.93, green:0.93, blue:0.93, alpha:1.0)
        navigationController?.navigationBar.barTintColor = UIColor(red:0.14, green:0.68, blue:1.00, alpha:1.0)
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(pulledToRefresh), for: .valueChanged)
        
        let r1 = Restaurant(name: "Northstar House", typeOfFood: .American, rating: .moderate, costLevel: .two, imgName: "r1")
        let r2 = Restaurant(name: "The Antlers", typeOfFood:  .American, rating: .good, costLevel: .two, imgName: "r2")
        let r3 = Restaurant(name: "Tian Jin Foods", typeOfFood: .Chinese, rating: .good, costLevel: .one, imgName: "r3")
       let r4 = Restaurant(name: "Hai Hong Restaurant", typeOfFood: .Chinese, rating: .good, costLevel: .two, imgName: "r4")
        let r5 = Restaurant(name: "Ithaca Sumo Japanese Hibachi and Sushi", typeOfFood: .Japanese, rating: .good, costLevel: .two, imgName: "r5")
        let r6 = Restaurant(name: "Tibetan Momo Bar", typeOfFood: .Japanese, rating: .good, costLevel: .one, imgName: "r6")
        let r7 = Restaurant(name: "Koko Korean Restaurant", typeOfFood: .Korean, rating: .moderate, costLevel: .two, imgName: "r7")
        let r8 = Restaurant(name: "Four Seasons", typeOfFood: .Korean, rating: .moderate, costLevel: .two, imgName: "r8")
        let r9 = Restaurant(name: "Thai Basil", typeOfFood: .Thai, rating: .good, costLevel: .two, imgName: "r9")
        let r10 = Restaurant(name: "Taste of Thai", typeOfFood: .Thai, rating: .moderate, costLevel: .two, imgName: "r10")
        
       restaurantArray = [r1, r2, r3, r4, r5, r6, r7, r8, r9, r10]
       filteredRestaurantArray = restaurantArray
        
        attributesDict = [
            "foodType": ["American", "Chinese", "Japanese", "Korean", "Thai"],
            "rating": ["terrible", "bad", "moderate", "good", "great"]]
        attributesArray = ["American", "Chinese", "Japanese", "Korean", "Thai", "terrible", "bad", "moderate", "good", "great"]
        
       let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = padding
        layout.minimumInteritemSpacing = padding
        layout.sectionInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        twoPerRowCollectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        twoPerRowCollectionView.translatesAutoresizingMaskIntoConstraints = false
        twoPerRowCollectionView.backgroundColor = UIColor(red:0.93, green:0.93, blue:0.93, alpha:1.0)

        twoPerRowCollectionView.delegate = self
        twoPerRowCollectionView.dataSource = self
        twoPerRowCollectionView.register(RestaurantCollectionViewCell.self, forCellWithReuseIdentifier: restaurantCellReuseIdentifier)
        self.view.addSubview(twoPerRowCollectionView)
        view.addSubview(twoPerRowCollectionView)
        
        let filterLayout = UICollectionViewFlowLayout()
        filterLayout.scrollDirection = .horizontal
        filterLayout.minimumInteritemSpacing = padding
        filterLayout.sectionInset = UIEdgeInsets(top: 10, left: 8, bottom: 10, right: 8)
        
        filterCollectionView = UICollectionView(frame: .zero, collectionViewLayout: filterLayout)
        filterCollectionView.translatesAutoresizingMaskIntoConstraints = false
        filterCollectionView.backgroundColor = UIColor(red:0.93, green:0.93, blue:0.93, alpha:1.0)
        filterCollectionView.delegate = self
        filterCollectionView.dataSource = self
        filterCollectionView.allowsMultipleSelection = true
        filterCollectionView.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier: filterReuseIdentifier)
        self.view.addSubview(filterCollectionView)
        view.addSubview(filterCollectionView)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        
        NSLayoutConstraint.activate([
            twoPerRowCollectionView.topAnchor.constraint(equalTo: filterCollectionView.bottomAnchor),
            twoPerRowCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            twoPerRowCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            twoPerRowCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            ])
        NSLayoutConstraint.activate([
            filterCollectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            filterCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            filterCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            filterCollectionView.heightAnchor.constraint(equalToConstant: 40)
            ])
    }
    
    // cell data source
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.filterCollectionView {
            let cell = filterCollectionView.dequeueReusableCell(withReuseIdentifier: filterReuseIdentifier, for: indexPath) as! FilterCollectionViewCell
            let attr = attributesArray[indexPath.item]
            cell.configure(for: attr)
            cell.setNeedsUpdateConstraints()
            return cell
        } else {
            let cell = twoPerRowCollectionView.dequeueReusableCell(withReuseIdentifier: restaurantCellReuseIdentifier, for: indexPath) as! RestaurantCollectionViewCell
            let restaurant: Restaurant!
            restaurant = filteredRestaurantArray[indexPath.item]
            
            cell.configure(for: restaurant)
            cell.setNeedsUpdateConstraints()
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.filterCollectionView {
            return attributesArray.count
        } else {
            return filteredRestaurantArray.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.filterCollectionView {
//            print("selected:", filterCollectionView.indexPathsForSelectedItems)
//            filteredRestaurantArray = []
//
//            var attr = ""
//            for selectedAttr in filterCollectionView!.indexPathsForSelectedItems! {
//                attr = attributesArray[selectedAttr[1]]
////                print(attr)
//                for restaurant in restaurantArray {
//                    if ("\(restaurant.typeOfFood)" == attr) && ("\(restaurant.rating)" == attr) {
//                        filteredRestaurantArray.append(restaurant)
//                    }
//                }
//            }
//            twoPerRowCollectionView.reloadData()
            
            filter()
        } else {   // push to restaurant detail page
            let restaurant = restaurantArray![indexPath.item]
            let resVC = ResDetailViewController()
            resVC.restaurant = restaurant
            navigationController?.pushViewController(resVC, animated: true)
        }
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        if collectionView == self.filterCollectionView {
//            var deselectedAttr = ""
//            var restaurant: Restaurant!
//            deselectedAttr = attributesArray[indexPath.item]
////                print("deselected:", deselectedAttr, filterCollectionView.indexPathsForSelectedItems)
//            filteredRestaurantArray.removeAll(where: {"\($0.typeOfFood)" == deselectedAttr || "\($0.rating)" == deselectedAttr})
//            if filterCollectionView.indexPathsForSelectedItems?.count == 0 {
//                filteredRestaurantArray = restaurantArray
//            }
//            twoPerRowCollectionView.reloadData()
            filter()
        }
    }
        
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == self.filterCollectionView {
            return CGSize(width: 80, height: 30)
        }
        let length = (twoPerRowCollectionView.frame.width - padding * 3) / 2.0
        return CGSize(width: length, height: length)
    }

    @objc func pulledToRefresh() {
        // Place some code here that fetches new data
        // Then call refreshControl.endRefreshing() once we get that data back
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.refreshControl.endRefreshing()
        }
    }
    
    // triggered if any update (select / deselect) on the filters
    func filter() {
        filteredRestaurantArray = []
        
        var attr = ""
        var selectedFoodType = [String]()
        var selectedRating = [String]()
        if filterCollectionView.indexPathsForSelectedItems?.count == 0 {
            filteredRestaurantArray = restaurantArray
        } else {
            for selectedAttr in filterCollectionView!.indexPathsForSelectedItems! {
                attr = attributesArray[selectedAttr[1]]
                print(attr)
                if (attributesDict["foodType"]!.contains(attr)) {
                    selectedFoodType.append(attr)
                } else {
                    selectedRating.append(attr)
                }
            }
            for restaurant in restaurantArray {
                if selectedFoodType.contains("\(restaurant.typeOfFood)") && selectedRating.contains("\(restaurant.rating)") {
                    filteredRestaurantArray.append(restaurant)
                } else if selectedFoodType.count == 0 && selectedRating.contains("\(restaurant.rating)") {
                    filteredRestaurantArray.append(restaurant)
                } else if selectedFoodType.contains("\(restaurant.typeOfFood)") && selectedRating.count == 0 {
                    filteredRestaurantArray.append(restaurant)
                }
            }
        }
        twoPerRowCollectionView.reloadData()
    }
    
    
    
    // headerView
    //    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
    //        let headerView = twoPerRowCollectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: headerReuseIdentifier, for: indexPath)
    //        headerView.setNeedsUpdateConstraints()
    //        return headerView
    //    }
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
    //        return CGSize(width: twoPerRowCollectionView.frame.width, height: headerHeight)
    //    }
}

